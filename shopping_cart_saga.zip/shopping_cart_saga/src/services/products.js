export default [
    { id: 1, title: 'iPhone', price: 89500.00, inventory: 2 },
    { id: 2, title: 'WROGN T-Shirt White', price: 4510.99, inventory: 10 },
    { id: 3, title: 'iPad', price: 35000.99, inventory: 5 },
  ]